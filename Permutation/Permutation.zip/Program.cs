﻿using System;

namespace Permutation
{
    class Program
    {
        static void Main(string[] args)
        {
            Permutation per = new Permutation();

            string[] arr = {"A", "AA", "AB", "ABC", "AAC"};

            foreach(string s in arr)
            {
                char[] charArray = s.ToCharArray();

                per.Permuter(charArray, 0, (s.Length - 1));

                Console.WriteLine("");
                Console.WriteLine("-------------------------------------------");
                Console.WriteLine("");
            }
            Console.ReadKey();
        }
    }
}
